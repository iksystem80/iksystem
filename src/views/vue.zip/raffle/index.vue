<template>
  <div ref="rafflePageRef" class="app-container raffle-page">
    <div class="raffle-topbar">
      <div>
        <h2>Raffle</h2>
        <p>{{ step === 1 ? "Spin the wheel to select today's winning machine." : step === 2 ? 'Select the raffle prize to deduct from the current employee session bank.' : 'Select the winner and capture a photo.' }}</p>
      </div>
      <el-button class="back-button"
                 :icon="Setting"
                 @click="router.push('/raffle/settings')" />
    </div>

    <div class="employee-strip employee-strip-dark">
      <div class="employee-avatar">{{ initials }}</div>
      <div>
        <small>CURRENT EMPLOYEE</small>
        <strong>{{ userStore.name || 'Employee' }}</strong>
      </div>
      <div class="employee-time">
        <small>CURRENT TIME</small>
        <strong>{{ currentTime }}</strong>
      </div>
    </div>

    <el-card class="raffle-card" shadow="never">
      <Teleport to="body">
        <div v-if="showFireworks" class="fireworks" aria-hidden="true">
          <div v-for="burst in 9" :key="burst" class="firework" :style="{ '--burst': burst }">
            <span v-for="spark in 28" :key="spark" class="firework-spark" :style="{ '--spark': spark }"></span>
            <span v-for="spark in 18" :key="`inner-${spark}`" class="firework-spark firework-spark-inner" :style="{ '--spark': spark }"></span>
          </div>
        </div>
      </Teleport>

      <div v-if="loading" class="raffle-loading">
        <el-icon class="is-loading"><Loading /></el-icon>
        Loading raffle...
      </div>

      <template v-else>
        <template v-if="step === 1">
          <div class="wheel-stage">
            <div class="pointer"></div>
            <div class="wheel" :class="{ spinning }" :style="wheelStyle"></div>
            <div class="wheel-center">
              <small>{{ result ? 'SELECTED MACHINE' : 'MACHINE' }}</small>
              <strong>{{ centerNumber }}</strong>
            </div>
          </div>

          <div v-if="!result" class="spin-actions">
            <el-button type="primary"
                       size="large"
                       round
                       :loading="spinning"
                       :disabled="!machines.length"
                       @click="spin">
              SPIN THE WHEEL
            </el-button>
          </div>

          <div v-if="result && !spinning" class="draw-result">
            <div class="machine-result">
              <small>SELECTED MACHINE</small>
              <strong>#{{ result.machine.machineNumber }}</strong>
            </div>
          </div>
        </template>

        <div v-else-if="step === 2" class="prize-page">
          <div class="prize-machine raffle-value-box">
            <small>WINNING MACHINE</small>
            <strong>#{{ result?.machine?.machineNumber }}</strong>
          </div>
          <div class="prize-heading">Select Prize</div>
          <div class="prize-grid">
            <el-button v-for="amount in [25, 50, 100, 150, 200, 250]"
                       :key="amount"
                       size="large"
                       :type="payout.amount === amount ? 'primary' : 'default'"
                       @click="selectPrize(amount)">
              ${{ amount }}
            </el-button>
          </div>
          <div class="custom-prize-row">
            <span>Custom Prize</span>
            <el-input v-model.number="payout.amount"
                      class="custom-prize-input"
                      type="number"
                      inputmode="decimal"
                      min="1"
                      placeholder="Enter amount">
              <template #prepend>
                $
              </template>
            </el-input>
          </div>
        </div>

        <div v-else class="payout-page payout-page-full">
          <el-row :gutter="20">
            <el-col :xs="24" :md="10">
              <div class="winner-details-column">
                <div class="winner-summary-row">
                  <div class="winner-summary-item raffle-value-box">
                    <small>WINNING MACHINE</small>
                    <strong>#{{ result?.machine?.machineNumber }}</strong>
                  </div>
                  <div class="winner-summary-item raffle-value-box">
                    <small>SELECTED PRIZE</small>
                    <strong>${{ Number(payout.amount || 0).toLocaleString() }}</strong>
                  </div>
                </div>

                <el-card shadow="never" class="payout-section winner-details-card">
                  <template #header>
                    <div>
                      <strong>Winner Details</strong>
                      <div class="small-text">Choose any customer registered at this location.</div>
                    </div>
                  </template>

                  <el-form label-position="top">
                    <el-form-item label="Customer">
                      <el-select v-model="payout.customerId"
                                 filterable
                                 clearable
                                 placeholder="Select customer"
                                 style="width: 100%"
                                 :loading="customersLoading">
                        <el-option v-for="customer in customers"
                                   :key="customer.id"
                                   :label="`${customer.firstname || ''} ${customer.lastname || ''}`.trim()"
                                   :value="Number(customer.id)" />
                      </el-select>
                    </el-form-item>

                  </el-form>

                </el-card>
              </div>
            </el-col>

            <el-col :xs="24" :md="14">
              <el-card shadow="never" class="payout-section camera-card step-three-camera-card">
                <template #header>
                  <div>
                    <strong>Winner Photo</strong>
                    <div class="small-text">Capture a current photo of the raffle winner.</div>
                  </div>
                </template>

                <div v-if="photoPreview" class="winner-photo-preview">
                  <img :src="photoPreview" alt="Winner photo">
                  <el-button @click="retakePhoto">Retake Photo</el-button>
                </div>

                <div class="raffle-camera-frame">
                  <CameraApp v-if="!photoPreview"
                             ref="cameraRef"
                             shape="custom"
                             width="100%"
                             height="375px"
                             border-radius="0 0 2% 2%"
                             @captured="handleCapturedImage" />
                </div>
              </el-card>
            </el-col>
          </el-row>
        </div>
      </template>
    </el-card>

    <Transition name="action-bar-fade">
      <div v-if="result && !spinning"
           class="fixed-actions"
           :style="actionBarStyle">
        <div class="action-inner">
          <div class="action-left">
            <el-button v-if="step === 3" :icon="ArrowLeft" @click="backToPrize">Back</el-button>
            <el-button v-else @click="resetRaffle">New Raffle</el-button>
          </div>

          <div class="action-right">
            <el-button v-if="step === 1"
                       type="primary"
                       @click="openPrize">
              Continue to Prize
              <el-icon><ArrowRight /></el-icon>
            </el-button>

            <el-button v-else-if="step === 2"
                       type="primary"
                       :disabled="!payout.amount"
                       @click="openWinner">
              Continue
              <el-icon><ArrowRight /></el-icon>
            </el-button>

            <el-button v-else
                       type="success"
                       :loading="saving"
                       :disabled="!payout.customerId || !payout.amount || !photoFile"
                       @click="saveWinner">
              Save & Finalize
            </el-button>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';
import { ArrowLeft, ArrowRight, Loading, Setting } from '@element-plus/icons-vue';
import { useUserStore } from '@/store/modules/user';
import CameraApp from '@/components/Camera';
import { getcustomers } from '@/api/customer';
import { completeRaffle, getRaffleState, startRaffle } from '@/api/raffle';

const router = useRouter();
const userStore = useUserStore();

const rafflePageRef = ref(null);
const cameraRef = ref(null);
const loading = ref(true);
const customersLoading = ref(false);
const spinning = ref(false);
const saving = ref(false);
const step = ref(1);
const payoutMode = computed(() => step.value === 3);
const machines = ref([]);
const customers = ref([]);
const result = ref(null);
const showFireworks = ref(false);
const rotation = ref(0);
const centerNumber = ref('?');
const spinDuration = ref(8);
const currentTime = ref('');
const photoFile = ref(null);
const photoPreview = ref('');
const payout = reactive({ amount: 25, customerId: null });
const actionBarStyle = ref({ left: '0px', width: '100%' });

let timer;
let fireworksTimer;
let numberTimer;
let actionBarResizeObserver;
let actionBarFrame = 0;

const initials = computed(() =>
  String(userStore.name || 'E')
    .split(/\s+/)
    .map(x => x[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
);

const wheelStyle = computed(() => {
  const count = Math.max(machines.value.length, 1);
  const slice = 360 / count;
  const colors = ['#f8e7a2', '#a9dfc0', '#a9d3e8', '#f5b89d'];
  const segments = [];

  for (let i = 0; i < count; i++) {
    const start = i * slice;
    const end = (i + 1) * slice;
    segments.push(`${colors[i % colors.length]} ${start}deg ${end}deg`);
  }

  return {
    '--spin-duration': `${spinDuration.value}s`,
    background: `conic-gradient(${segments.join(', ')})`,
    transform: `rotate(${rotation.value}deg)`
  };
});

function updateClock() {
  currentTime.value = new Date().toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

function updateActionBarPosition() {
  if (!rafflePageRef.value) return;
  const rect = rafflePageRef.value.getBoundingClientRect();
  actionBarStyle.value = {
    left: `${rect.left}px`,
    width: `${rect.width}px`
  };
}

function scheduleActionBarUpdate() {
  cancelAnimationFrame(actionBarFrame);
  actionBarFrame = requestAnimationFrame(updateActionBarPosition);
}

async function load() {
  loading.value = true;
  try {
    const response = await getRaffleState();
    machines.value = response.data?.machines || [];
    spinDuration.value = Number(response.data?.settings?.spinDurationSeconds || 8);
  } finally {
    loading.value = false;
    await nextTick();
    scheduleActionBarUpdate();
  }
}

async function spin() {
  if (spinning.value) return;
  spinning.value = true;

  const numbers = machines.value.map(machine => machine.machineNumber);
  let numberIndex = Math.floor(Math.random() * Math.max(numbers.length, 1));

  clearInterval(numberTimer);
  if (numbers.length) {
    centerNumber.value = numbers[numberIndex];
    numberTimer = setInterval(() => {
      numberIndex = (numberIndex + 1) % numbers.length;
      centerNumber.value = numbers[numberIndex];
    }, 90);
  }

  try {
    const response = await startRaffle();
    const next = response.data;
    const index = machines.value.findIndex(
      machine => Number(machine.id) === Number(next.machine.id)
    );
    const slice = 360 / Math.max(machines.value.length, 1);
    const target = index >= 0
      ? 360 - ((index * slice) + (slice / 2))
      : 0;
    const current = ((rotation.value % 360) + 360) % 360;
    const normalizedTarget = ((target % 360) + 360) % 360;
    const delta = (normalizedTarget - current + 360) % 360;

    rotation.value += (8 * 360) + delta;
    await new Promise(resolve =>
      setTimeout(resolve, spinDuration.value * 1000)
    );

    clearInterval(numberTimer);
    numberTimer = null;

    result.value = next;
    centerNumber.value = next.machine.machineNumber;

    showFireworks.value = true;
    clearTimeout(fireworksTimer);
    fireworksTimer = setTimeout(() => {
      showFireworks.value = false;
    }, 5000);

    await nextTick();
    scheduleActionBarUpdate();
  } catch (error) {
    clearInterval(numberTimer);
    numberTimer = null;
    centerNumber.value = '?';
    ElMessage.error(
      error?.response?.data?.message ||
        error?.message ||
        'Unable to run raffle.'
    );
  } finally {
    spinning.value = false;
  }
}

function selectPrize(amount) {
  payout.amount = amount;
}

function openPrize() {
  step.value = 2;
  payout.customerId = null;
}

function backToPrize() {
  step.value = 2;
  payout.customerId = null;
}

async function openWinner() {
  step.value = 3;
  payout.customerId = null;
  customersLoading.value = true;

  try {
    const response = await getcustomers(userStore.locationId);
    customers.value = Array.isArray(response.data) ? response.data : [];
  } catch (error) {
    customers.value = [];
    ElMessage.error(
      error?.response?.data?.message ||
        error?.message ||
        'Unable to load customers.'
    );
  } finally {
    customersLoading.value = false;
    await nextTick();
    scheduleActionBarUpdate();
  }
}

function handleCapturedImage(image) {
  if (!image) return;

  photoFile.value = image;

  if (photoPreview.value) {
    URL.revokeObjectURL(photoPreview.value);
  }

  photoPreview.value = URL.createObjectURL(image);
}

async function retakePhoto() {
  if (photoPreview.value) {
    URL.revokeObjectURL(photoPreview.value);
  }

  photoPreview.value = '';
  photoFile.value = null;

  await nextTick();
  cameraRef.value?.startCamera?.();
}

async function saveWinner() {
  if (!payout.customerId || !payout.amount || !photoFile.value) {
    ElMessage.warning(
      'Customer, winning amount and winner photo are required.'
    );
    return;
  }

  saving.value = true;

  try {
    const form = new FormData();
    form.append('customerid', String(payout.customerId));
    form.append('amount', String(payout.amount));
    form.append('image', photoFile.value, photoFile.value.name || 'raffle-winner.jpg');

    await completeRaffle(result.value.raffleId, form);

    ElMessage.success('Raffle completed and payout recorded.');
    await resetRaffle();
  } catch (error) {
    ElMessage.error(
      error?.response?.data?.message ||
        error?.message ||
        'Unable to complete raffle payout.'
    );
  } finally {
    saving.value = false;
  }
}

async function resetRaffle() {
  result.value = null;
  step.value = 1;
  payout.customerId = null;
  payout.amount = 25;
  customers.value = [];
  showFireworks.value = false;

  clearTimeout(fireworksTimer);
  clearInterval(numberTimer);

  rotation.value = 0;
  centerNumber.value = '?';
  photoFile.value = null;

  if (photoPreview.value) {
    URL.revokeObjectURL(photoPreview.value);
  }

  photoPreview.value = '';

  await load();
}

onMounted(async () => {
  await load();
  updateClock();
  timer = setInterval(updateClock, 1000);

  await nextTick();
  updateActionBarPosition();

  if (rafflePageRef.value) {
    actionBarResizeObserver = new ResizeObserver(scheduleActionBarUpdate);
    actionBarResizeObserver.observe(rafflePageRef.value);
  }

  window.addEventListener('resize', scheduleActionBarUpdate);
  window.addEventListener('transitionend', scheduleActionBarUpdate);
});

onBeforeUnmount(() => {
  clearInterval(timer);
  clearTimeout(fireworksTimer);
  clearInterval(numberTimer);
  actionBarResizeObserver?.disconnect();
  cancelAnimationFrame(actionBarFrame);
  window.removeEventListener('resize', scheduleActionBarUpdate);
  window.removeEventListener('transitionend', scheduleActionBarUpdate);

  if (photoPreview.value) {
    URL.revokeObjectURL(photoPreview.value);
  }
});
</script>

<style scoped>
  .raffle-page {
    padding: 20px;
    max-width: 1050px;
    margin: 0 auto;
    min-height: calc(100dvh - 50px);
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    overflow-x: hidden
  }

  .raffle-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px
  }

    .raffle-topbar h2 {
      margin: 0;
      font-size: 24px
    }

    .raffle-topbar p {
      margin: 4px 0 0;
      color: var(--el-text-color-secondary);
      font-size: 13px
    }

  .raffle-card {
    position: relative;
    flex: 1;
    border-radius: 18px;
    overflow: hidden
  }

    .raffle-card :deep(.el-card__body) {
      min-height: 100%;
      box-sizing: border-box
    }

  .raffle-loading {
    padding: 80px;
    text-align: center
  }

  .employee-strip {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: 12px;
    background: var(--el-fill-color-light);
    max-width: 650px;
    margin: 0 auto 22px
  }

  /*.raffle-camera-frame {
    width: 100%;
    aspect-ratio: 4 / 4;
    overflow: hidden;
    background: #000;
  }*/

  .employee-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background: #111827;
    color: white;
    font-weight: 700
  }

  .employee-strip small, .machine-result small {
    display: block;
    color: var(--el-text-color-secondary);
    font-size: 10px;
    font-weight: 700
  }

  .employee-strip strong {
    display: block
  }

  .employee-time {
    margin-left: auto;
    text-align: right
  }

  .wheel-stage {
    position: relative;
    width: 420px;
    height: 420px;
    margin: 10px auto 22px;
    overflow: hidden;
    border-radius: 50%
  }

  .wheel {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    border: 10px solid #fff;
    box-sizing: border-box;
    transition: transform var(--spin-duration) cubic-bezier(.12,.72,.08,1)
  }

  .wheel-center {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    width: 118px;
    height: 118px;
    border-radius: 50%;
    background: #111;
    border: 7px solid #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
    z-index: 6;
    box-shadow: 0 5px 18px rgba(0,0,0,.3)
  }

    .wheel-center small {
      font-size: 9px;
      font-weight: 800;
      letter-spacing: 1px;
      opacity: .72;
      text-align: center
    }

    .wheel-center strong {
      margin-top: 4px;
      font-size: 43px;
      font-weight: 900;
      line-height: 1
    }

  .pointer {
    position: absolute;
    z-index: 10;
    left: 50%;
    top: -8px;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 16px solid transparent;
    border-right: 16px solid transparent;
    border-top: 30px solid #111;
    filter: drop-shadow(0 3px 2px rgba(0,0,0,.22))
  }

  .fireworks {
    position: fixed;
    inset: 0;
    z-index: 99999;
    width: 100vw;
    height: 100dvh;
    overflow: hidden;
    pointer-events: none;
    background: transparent !important
  }

  .firework {
    --x: 50%;
    --y: 40%;
    --size: 150px;
    --delay: 0ms;
    --hue: 42;
    position: absolute;
    left: var(--x);
    top: var(--y);
    width: 2px;
    height: 2px;
    opacity: 0;
    animation: firework-burst-visibility 1.45s ease-out var(--delay) forwards
  }

    .firework:nth-child(1) {
      --x: 15%;
      --y: 24%;
      --size: 170px;
      --delay: 0ms;
      --hue: 42
    }

    .firework:nth-child(2) {
      --x: 48%;
      --y: 18%;
      --size: 210px;
      --delay: 160ms;
      --hue: 196
    }

    .firework:nth-child(3) {
      --x: 80%;
      --y: 27%;
      --size: 180px;
      --delay: 330ms;
      --hue: 330
    }

    .firework:nth-child(4) {
      --x: 28%;
      --y: 48%;
      --size: 220px;
      --delay: 480ms;
      --hue: 122
    }

    .firework:nth-child(5) {
      --x: 70%;
      --y: 50%;
      --size: 230px;
      --delay: 620ms;
      --hue: 18
    }

    .firework:nth-child(6) {
      --x: 9%;
      --y: 70%;
      --size: 165px;
      --delay: 790ms;
      --hue: 270
    }

    .firework:nth-child(7) {
      --x: 89%;
      --y: 68%;
      --size: 190px;
      --delay: 930ms;
      --hue: 55
    }

    .firework:nth-child(8) {
      --x: 47%;
      --y: 76%;
      --size: 205px;
      --delay: 1080ms;
      --hue: 205
    }

    .firework:nth-child(9) {
      --x: 58%;
      --y: 37%;
      --size: 155px;
      --delay: 1220ms;
      --hue: 350
    }

  .firework-spark {
    --angle: calc((var(--spark) - 1) * 12.857deg);
    position: absolute;
    left: 0;
    top: 0;
    width: 2px;
    height: calc(var(--size) * .34);
    border-radius: 999px;
    transform-origin: 50% 0;
    transform: rotate(var(--angle)) scaleY(.05);
    opacity: 0;
    background: linear-gradient( to bottom, hsla(var(--hue), 100%, 96%, 1) 0%, hsla(var(--hue), 100%, 72%, .98) 15%, hsla(var(--hue), 100%, 62%, .72) 52%, hsla(var(--hue), 100%, 58%, 0) 100% );
    filter: drop-shadow(0 0 3px hsla(var(--hue), 100%, 70%, .9));
    animation: firework-trail 1.15s cubic-bezier(.1,.65,.2,1) var(--delay) forwards
  }

    .firework-spark::after {
      content: '';
      position: absolute;
      left: 50%;
      bottom: -3px;
      width: 4px;
      height: 4px;
      border-radius: 50%;
      transform: translateX(-50%);
      background: hsl(var(--hue), 100%, 88%);
      box-shadow: 0 0 7px 2px hsla(var(--hue), 100%, 68%, .8)
    }

  .firework-spark-inner {
    --angle: calc((var(--spark) - 1) * 20deg);
    height: calc(var(--size) * .22);
    animation-duration: .95s;
    animation-delay: calc(var(--delay) + 90ms);
    filter: drop-shadow(0 0 2px hsla(var(--hue), 100%, 76%, .85))
  }

  @keyframes firework-burst-visibility {
    0% {
      opacity: 0
    }

    3% {
      opacity: 1
    }

    82% {
      opacity: 1
    }

    100% {
      opacity: 0
    }
  }

  @keyframes firework-trail {
    0% {
      opacity: 0;
      transform: rotate(var(--angle)) translateY(0) scaleY(.03)
    }

    8% {
      opacity: 1
    }

    45% {
      opacity: 1;
      transform: rotate(var(--angle)) translateY(calc(var(--size) * -.24)) scaleY(.92)
    }

    72% {
      opacity: .75;
      transform: rotate(var(--angle)) translateY(calc(var(--size) * -.42)) scaleY(1)
    }

    100% {
      opacity: 0;
      transform: rotate(var(--angle)) translateY(calc(var(--size) * -.55)) scaleY(.5)
    }
  }

  .spin-actions {
    text-align: center
  }

    .spin-actions .el-button {
      min-width: 210px;
      font-weight: 800
    }

  .draw-result {
    max-width: 650px;
    margin: 22px auto 0;
    display: grid;
    gap: 14px;
    text-align: center
  }

  .machine-result strong {
    display: block;
    font-size: 36px
  }

  .winner-banner {
    padding: 14px;
    border-radius: 12px;
    background: #ecfdf3;
    color: #067647
  }

    .winner-banner span {
      display: block;
      font-size: 10px;
      font-weight: 800
    }

    .winner-banner strong {
      font-size: 20px
    }

  .photo-input {
    width: 100%;
    padding: 12px;
    border: 1px dashed var(--el-border-color);
    border-radius: 8px
  }

  .photo-preview {
    width: 100%;
    max-height: 220px;
    object-fit: cover;
    border-radius: 10px;
    margin-top: 10px
  }

  @media(max-width:600px) {
    .raffle-page {
      padding: 12px
    }

    .wheel-stage {
      width: 310px;
      height: 310px
    }

    .employee-strip {
      padding: 10px
    }

    .raffle-topbar p {
      max-width: 260px
    }
  }

  .raffle-page {
    padding-bottom: 88px;
  }

  .payout-page {
    max-width: 900px;
    margin: 0 auto;
    padding: 8px 0 24px;
  }

  .payout-heading {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 18px;
  }

    .payout-heading h2 {
      margin: 3px 0 4px;
      font-size: 22px;
    }

    .payout-heading p,
    .small-text {
      margin: 0;
      color: var(--el-text-color-secondary);
      font-size: 12px;
    }

  .eyebrow {
    color: var(--el-color-primary);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.1px;
  }

  .payout-section {
    height: 100%;
    border-radius: 12px;
  }

    .payout-section :deep(.el-card__header) {
      padding: 14px 16px;
    }

    .payout-section :deep(.el-card__body) {
      padding: 16px;
    }

  .winner-photo-preview {
    display: flex;
    flex-direction: column;
    gap: 12px;
    align-items: center;
  }

    .winner-photo-preview img {
      display: block;
      width: 100%;
      max-height: 430px;
      object-fit: contain;
      border-radius: 12px;
      background: var(--el-fill-color-light);
    }

  /* Same fixed bottom action-bar structure used by Reading Session. */
  .fixed-actions {
    position: fixed;
    right: auto;
    bottom: 0;
    z-index: 1000;
    box-sizing: border-box;
    padding: 12px 20px calc(12px + env(safe-area-inset-bottom, 0px));
    border-top: 1px solid var(--el-border-color-lighter);
    background: var(--el-bg-color);
    box-shadow: 0 -4px 16px rgba(0, 0, 0, .05);
  }

  .action-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    max-width: 1050px;
    margin: 0 auto;
  }

  .action-left,
  .action-right {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .action-bar-fade-enter-active,
  .action-bar-fade-leave-active {
    transition: opacity .22s ease, transform .22s ease;
  }

  .action-bar-fade-enter-from,
  .action-bar-fade-leave-to {
    opacity: 0;
    transform: translateY(12px);
  }

  @media (max-width: 767px) {
    .payout-heading {
      align-items: stretch;
      flex-direction: column;
    }

    .payout-section {
      margin-bottom: 16px;
    }

    .fixed-actions {
      padding-left: 12px;
      padding-right: 12px;
    }

    .action-inner {
      gap: 10px;
    }

    .action-left,
    .action-right {
      flex: 1;
    }

      .action-left .el-button,
      .action-right .el-button {
        width: 100%;
        margin: 0;
      }
  }

  /* ==========================================================
     FIXED BOTTOM ACTION BAR — SAME BEHAVIOR AS RECORD READING
     ========================================================== */
  .raffle-page {
    width: 100%;
    max-width: none !important;
    margin: 0 !important;
    padding-bottom: 85px !important;
    box-sizing: border-box;
  }

  .fixed-actions {
    position: fixed;
    bottom: 0;
    z-index: 1000;
    box-sizing: border-box;
    border-top: 1px solid var(--el-border-color-lighter);
    background: rgba(255, 255, 255, 0.97);
    box-shadow: 0 -3px 14px rgba(0, 0, 0, 0.08);
    backdrop-filter: blur(10px);
    transition: left 0.28s ease, width 0.28s ease;
    will-change: transform, opacity;
    padding: 0 !important;
  }

  .action-bar-fade-enter-active {
    transition: opacity 0.36s ease, transform 0.36s cubic-bezier(0.22, 1, 0.36, 1) !important;
  }

  .action-bar-fade-leave-active {
    transition: opacity 0.30s ease, transform 0.30s cubic-bezier(0.4, 0, 1, 1) !important;
  }

  .action-bar-fade-enter-from,
  .action-bar-fade-leave-to {
    opacity: 0;
    transform: translateY(110%);
  }

  .action-bar-fade-enter-to,
  .action-bar-fade-leave-from {
    opacity: 1;
    transform: translateY(0);
  }

  .action-inner {
    width: 100%;
    min-height: 64px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
    max-width: none !important;
    margin: 0 !important;
  }

  .action-left {
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }

  .action-right {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
  }

  @media (max-width: 767px) {
    .raffle-page {
      padding-bottom: 75px !important;
    }

    .action-inner {
      min-height: 64px;
      padding: 10px 12px;
    }

    .action-left,
    .action-right {
      flex: initial;
    }

      .action-left .el-button,
      .action-right .el-button {
        width: auto;
      }
  }

  /* Captured winner photo keeps the same frame footprint as the camera. */
  .camera-card :deep(.el-card__body) {
    display: flex;
    flex-direction: column;
  }

  .winner-photo-preview {
    width: 100%;
    height: 430px;
    min-height: 430px;
    max-height: 430px;
    position: relative;
    overflow: hidden;
    border-radius: 12px;
    background: var(--el-fill-color-light);
  }

    .winner-photo-preview img {
      width: 100% !important;
      height: 100% !important;
      max-height: none !important;
      display: block;
      object-fit: cover;
      border-radius: 12px;
    }

    .winner-photo-preview .el-button {
      position: absolute;
      right: 12px;
      bottom: 12px;
      z-index: 2;
    }

  @media (max-width: 767px) {
    .winner-photo-preview {
      height: 320px;
      min-height: 320px;
      max-height: 320px;
    }
  }

  /* RAFFLE WINNER CAMERA — PAGE ONLY */
  .camera-card {
    overflow: hidden;
  }

    .camera-card :deep(.el-card__body) {
      padding: 0 !important;
      overflow: hidden;
    }

    .camera-card .winner-photo-preview {
      position: relative;
      display: block;
      width: 100%;
      height: 330px;
      min-height: 330px;
      max-height: 330px;
      overflow: hidden;
      border-radius: 0 0 2% 2%;
      background: #000;
    }

      .camera-card .winner-photo-preview img {
        display: block;
        width: 100% !important;
        height: 100% !important;
        max-height: none !important;
        object-fit: cover;
        border-radius: 0 0 5% 5%;
      }

      .camera-card .winner-photo-preview .el-button {
        position: absolute;
        right: 12px;
        bottom: 12px;
        z-index: 2;
      }

  .employee-strip-dark {
    max-width: none;
    margin: 0 0 16px;
    background: #111827;
    color: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 14px rgba(0,0,0,.08);
  }

    .employee-strip-dark small {
      color: rgba(255,255,255,.62);
    }

    .employee-strip-dark .employee-avatar {
      background: rgba(255,255,255,.14);
    }

  .prize-page {
    max-width: 720px;
    margin: 0 auto;
    padding: 18px 0 30px;
    text-align: center;
  }

  .prize-machine small {
    display: block;
    font-size: 10px;
    font-weight: 800;
    color: var(--el-text-color-secondary);
    letter-spacing: 1px;
  }

  .prize-machine strong {
    display: block;
    margin-top: 5px;
    font-size: 38px;
    font-weight: 900;
    line-height: 1;
  }

  .raffle-value-box {
    padding: 16px 18px;
    border: 1px solid var(--el-border-color-lighter);
    border-radius: 12px;
    background: var(--el-fill-color-light);
    text-align: center;
  }

    .raffle-value-box strong {
      color: #887baf;
    }

  .winner-machine-display {
    margin-top: 8px;
    padding: 18px 0 4px;
    text-align: center;
    border-top: 1px solid var(--el-border-color-lighter);
  }

    .winner-machine-display small {
      display: block;
      font-size: 10px;
      font-weight: 800;
      color: var(--el-text-color-secondary);
      letter-spacing: 1px;
    }

    .winner-machine-display strong {
      display: block;
      margin-top: 6px;
      font-size: 42px;
      font-weight: 900;
      line-height: 1;
    }

  .prize-heading {
    margin: 24px 0 14px;
    font-size: 20px;
    font-weight: 800;
  }

  .prize-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 12px;
  }

    .prize-grid .el-button {
      width: 100%;
      height: 58px;
      margin: 0;
      font-size: 18px;
      font-weight: 800;
    }

  .custom-prize-row {
    margin-top: 14px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: center;
    gap: 12px;
    padding: 14px;
    border: 1px solid var(--el-border-color-lighter);
    border-radius: 12px;
    text-align: left;
  }

    .custom-prize-row span {
      font-size: 13px;
      font-weight: 700;
    }

    .custom-prize-row .custom-prize-input {
      width: 100%;
    }

  .custom-prize-input :deep(.el-input__wrapper) {
    min-height: 58px;
  }

  .custom-prize-input :deep(.el-input__inner) {
    font-size: 24px;
    font-weight: 800;
  }

  .custom-prize-input :deep(.el-input-group__prepend) {
    font-size: 22px;
    font-weight: 800;
    padding: 0 18px;
  }

  .custom-prize-input :deep(input[type=number]::-webkit-inner-spin-button),
  .custom-prize-input :deep(input[type=number]::-webkit-outer-spin-button) {
    -webkit-appearance: none;
    margin: 0;
  }

  .custom-prize-input :deep(input[type=number]) {
    -moz-appearance: textfield;
    appearance: textfield;
  }

  @media(max-width:600px) {
    .prize-grid {
      grid-template-columns: repeat(2,1fr);
    }

    .custom-prize-row {
      grid-template-columns: 1fr;
    }
  }

  /* STEP 3 — full-width winner layout */
  .payout-page-full {
    width: 100%;
    max-width: none !important;
  }

  .winner-details-column {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 14px;
  }

  .winner-summary-row {
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
    margin: 0;
  }

  .winner-details-card {
    width: 100%;
  }

  .step-three-camera-card {
    width: 100%;
    height: 100%;
  }

  .winner-summary-item {
    min-width: 0;
  }

    .winner-summary-item small {
      display: block;
      color: var(--el-text-color-secondary);
      font-size: 10px;
      font-weight: 800;
      letter-spacing: 1px;
    }

    .winner-summary-item strong {
      display: block;
      margin-top: 5px;
      font-size: 38px;
      font-weight: 900;
      line-height: 1;
    }

  @media (max-width: 600px) {
    .winner-summary-row {
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }

    .winner-summary-item {
      padding: 14px 8px;
    }

      .winner-summary-item strong {
        font-size: 30px;
      }
  }
</style>

