<template>
  <div ref="ticketPageRef" class="app-container ticketout-page">
    <div class="ticket-topbar">
      <div>
        <h2>Ticket Out</h2>
        <p>{{ step === 1 ? 'Scan or enter the machine number.' : 'Enter payout details and capture the machine screen.' }}</p>
      </div>
    </div>

    <el-alert v-if="!state.cashReady" class="cash-alert" type="warning" :closable="false" show-icon
              title="Opening Bank must be available before a Ticket Out can be paid." />

    <Transition name="step-fade" mode="out-in">
      <!-- STEP 1 -->
      <el-card v-if="step === 1" key="scan" shadow="never" class="main-card scan-card">
        <div class="scan-stage">
          <div class="nfc-animation" :class="{ scanning: nfcScanning }">
            <div class="phone">
              <el-icon><Cellphone /></el-icon>
            </div>
            <span class="wave wave-1"></span>
            <span class="wave wave-2"></span>
            <span class="wave wave-3"></span>
          </div>

          <h3>{{ nfcScanning ? 'Hold phone near machine NFC tag' : 'Ready to Scan' }}</h3>
          <p class="scan-status">
            {{ nfcScanning ? 'Waiting for NFC...' : 'NFC scan is not active.' }}
          </p>

          <el-button v-if="!nfcScanning" type="primary" size="large" class="scan-again" @click="scanNfc">
            <el-icon><Connection /></el-icon>
            Start NFC Scan
          </el-button>
        </div>

        <div class="manual-divider"><span>OR ENTER MANUALLY</span></div>

        <div class="manual-box">
          <label class="input-label">Machine #</label>
          <div class="machine-input-row">
            <el-input v-model="machineNumber" inputmode="numeric" placeholder="Enter machine #"
                      clearable @keyup.enter="findMachine" @clear="clearMachine" />
            <el-button type="primary" :loading="machineLoading" @click="findMachine">Find</el-button>
          </div>
        </div>
      </el-card>

      <!-- STEP 2 -->
      <div v-else key="details" class="details-page">
        <div class="summary-row">
          <div class="value-box">
            <small>MACHINE</small>
            <strong>#{{ machine?.machineNumber }}</strong>
          </div>
          <div class="value-box">
            <small>TICKET OUT</small>
            <strong>{{ validAmount ? `$${Number(amount).toFixed(2)}` : '—' }}</strong>
          </div>
        </div>

        <el-row :gutter="16">
          <el-col :xs="24" :md="10">
            <el-card shadow="never" class="detail-card">
              <template #header>
                <div>
                  <strong>Ticket Out Details</strong>
                  <div class="small-text">Enter the payout amount and select the customer.</div>
                </div>
              </template>

              <el-form label-position="top">
                <el-form-item label="Cash Out Amount">
                  <el-input v-model="amount" inputmode="decimal" class="money-input" placeholder="0.00">
                    <template #prepend>
                      $
                    </template>
                  </el-input>
                </el-form-item>

                <el-form-item label="Customer">
                  <el-select v-model="customerId" filterable clearable placeholder="Select customer"
                             style="width:100%" :loading="customersLoading">
                    <el-option v-for="customer in customers" :key="customer.id"
                               :label="`${customer.firstname || ''} ${customer.lastname || ''}`.trim()"
                               :value="Number(customer.id)" />
                  </el-select>
                </el-form-item>
              </el-form>
            </el-card>
          </el-col>

          <el-col :xs="24" :md="14">
            <el-card shadow="never" class="detail-card camera-card">
              <template #header>
                <div>
                  <strong>Machine Screen Photo</strong>
                  <div class="small-text">Capture the screen showing the Ticket-Out amount.</div>
                </div>
              </template>

              <div v-if="photoPreview" class="photo-preview">
                <img :src="photoPreview" alt="Machine screen">
                <el-button @click="retakePhoto">Retake Photo</el-button>
              </div>

              <div v-else class="camera-frame">
                <CameraApp ref="cameraRef" shape="custom" width="100%" height="375px"
                           border-radius="0 0 2% 2%" @captured="handleCapturedImage" />
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>
    </Transition>

    <Transition name="action-bar-fade">
      <div v-if="step === 2" class="fixed-actions" :style="actionBarStyle">
        <div class="action-inner">
          <div class="action-left">
            <el-button :icon="ArrowLeft" :disabled="saving" @click="backToScan">Back</el-button>
          </div>
          <div class="action-right">
            <el-button type="success" :loading="saving" :disabled="!canSubmit" @click="submitTicketOut">
              Save & Finish
            </el-button>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref } from 'vue';
import { ElMessage } from 'element-plus';
import { ArrowLeft, Cellphone, Connection } from '@element-plus/icons-vue';
import { Capacitor } from '@capacitor/core';
import { CapacitorNfc } from '@capgo/capacitor-nfc';
import { useUserStore } from '@/store/modules/user';
import CameraApp from '@/components/Camera';
import { getcustomers } from '@/api/customer';
import { getTicketOutMachine, getTicketOutState, saveTicketOut } from '@/api/ticketOut';

const userStore = useUserStore();
const ticketPageRef = ref(null);
const cameraRef = ref(null);
const step = ref(1);
const state = reactive({ sessionId: null, locationId: null, balance: 0, cashReady: false });
const machineNumber = ref('');
const machine = ref(null);
const amount = ref('');
const customerId = ref(null);
const customers = ref([]);
const customersLoading = ref(false);
const photoFile = ref(null);
const photoPreview = ref('');
const machineLoading = ref(false);
const nfcScanning = ref(false);
const saving = ref(false);
const actionBarStyle = ref({ left: '0px', width: '100%' });

let nfcListener = null;
let nfcSessionEndListener = null;
let actionBarResizeObserver = null;
let actionBarFrame = 0;

const validAmount = computed(() =>
  /^\d+(?:\.\d{1,2})?$/.test(String(amount.value || '').trim()) && Number(amount.value) > 0
);
const canSubmit = computed(() =>
  Boolean(machine.value && validAmount.value && customerId.value && photoFile.value &&
      state.cashReady && Number(amount.value) <= Number(state.balance))
);

function updateActionBarPosition() {
  if (!ticketPageRef.value) return;
  const rect = ticketPageRef.value.getBoundingClientRect();
  actionBarStyle.value = { left: `${rect.left}px`, width: `${rect.width}px` };
}
function scheduleActionBarUpdate() {
  cancelAnimationFrame(actionBarFrame);
  actionBarFrame = requestAnimationFrame(updateActionBarPosition);
}

async function loadState() {
  try {
    const response = await getTicketOutState();
    Object.assign(state, response.data || {});
  } catch (error) {
    ElMessage.error(error?.response?.data?.message || error?.message || 'Unable to load Ticket Out status.');
  }
}

async function loadCustomers() {
  customersLoading.value = true;
  try {
    const response = await getcustomers(userStore.locationId);
    customers.value = Array.isArray(response.data) ? response.data : [];
  } catch (error) {
    customers.value = [];
    ElMessage.error(error?.response?.data?.message || error?.message || 'Unable to load customers.');
  } finally {
    customersLoading.value = false;
  }
}

function clearMachine() { machine.value = null; }

async function findMachine() {
  const number = String(machineNumber.value || '').trim();
  if (!number) return ElMessage.warning('Enter a machine number.');
  machineLoading.value = true;
  machine.value = null;
  try {
    const response = await getTicketOutMachine(number);
    machine.value = response.data;
    machineNumber.value = String(response.data.machineNumber);
    await openDetails();
  } catch (error) {
    ElMessage.error(error?.response?.data?.message || error?.message || `Machine #${number} was not found.`);
  } finally {
    machineLoading.value = false;
  }
}

function decodeNdefRecord(record) {
  const payload = Array.isArray(record?.payload) ? record.payload : [];
  if (!payload.length) return '';
  try {
    const type = String.fromCharCode(...(record.type || []));
    if (type === 'T') {
      const languageLength = payload[0] & 0x3f;
      return new TextDecoder('utf-8').decode(new Uint8Array(payload.slice(1 + languageLength))).trim();
    }
    return new TextDecoder('utf-8').decode(new Uint8Array(payload)).trim();
  } catch { return ''; }
}

function machineNumberFromNativeNfc(event) {
  for (const record of event?.tag?.ndefMessage || []) {
    const text = decodeNdefRecord(record);
    const match = text.match(/(?:machine(?:number)?[\s:#=-]*)?(\d+)/i);
    if (match) return match[1];
  }
  return '';
}

async function stopNfcScan() {
  try { await CapacitorNfc.stopScanning(); } catch { /* no active scan */ }
  if (nfcListener) {
    await nfcListener.remove();
    nfcListener = null;
  }
  if (nfcSessionEndListener) {
    await nfcSessionEndListener.remove();
    nfcSessionEndListener = null;
  }
  nfcScanning.value = false;
}

async function scanNfc() {
  if (step.value !== 1) return;
  if (!Capacitor.isNativePlatform()) {
    nfcScanning.value = false;
    return;
  }

  try {
    await stopNfcScan();
    const { supported } = await CapacitorNfc.isSupported();
    if (!supported) return ElMessage.warning('NFC is not supported on this device.');

    const { status } = await CapacitorNfc.getStatus();
    if (status === 'NFC_DISABLED') return ElMessage.warning('NFC is turned off. Enable NFC and try again.');
    if (status === 'NO_NFC') return ElMessage.warning('NFC is not available on this device.');

    nfcScanning.value = true;

    nfcListener = await CapacitorNfc.addListener('nfcEvent', async event => {
      const number = machineNumberFromNativeNfc(event);
      await stopNfcScan();
      if (!number) {
        ElMessage.error('The NFC tag does not contain a machine number.');
        await scanNfc();
        return;
      }
      machineNumber.value = number;
      await findMachine();
      if (step.value === 1) await scanNfc();
    });

    if (Capacitor.getPlatform() === 'ios') {
      nfcSessionEndListener = await CapacitorNfc.addListener('nfcSessionEnd', ({ reason }) => {
        nfcScanning.value = false;
        if (reason === 'sessionTimeout') ElMessage.warning('No NFC tag detected. Try again.');
        else if (reason !== 'userCancelled') ElMessage.error('The NFC scan session ended unexpectedly.');
      });
    }

    await CapacitorNfc.startScanning({
      invalidateAfterFirstRead: true,
      alertMessage: 'Hold the device near the machine NFC tag.',
      iosSessionType: 'ndef'
    });
  } catch (error) {
    await stopNfcScan();
    ElMessage.error(error?.message || 'Unable to scan NFC tag.');
  }
}

async function openDetails() {
  await stopNfcScan();
  step.value = 2;
  await loadCustomers();
  await nextTick();
  scheduleActionBarUpdate();
}

function handleCapturedImage(image) {
  if (!image) return;
  photoFile.value = image;
  if (photoPreview.value) URL.revokeObjectURL(photoPreview.value);
  photoPreview.value = URL.createObjectURL(image);
}

async function retakePhoto() {
  if (photoPreview.value) URL.revokeObjectURL(photoPreview.value);
  photoPreview.value = '';
  photoFile.value = null;
  await nextTick();
  cameraRef.value?.startCamera?.();
}

async function resetToScan() {
  await stopNfcScan();
  step.value = 1;
  machineNumber.value = '';
  machine.value = null;
  amount.value = '';
  customerId.value = null;
  customers.value = [];
  photoFile.value = null;
  if (photoPreview.value) URL.revokeObjectURL(photoPreview.value);
  photoPreview.value = '';
  await nextTick();
  await scanNfc();
}

async function backToScan() {
  await resetToScan();
}

async function submitTicketOut() {
  if (!canSubmit.value) return;
  saving.value = true;
  try {
    const form = new FormData();
    form.append('machineid', String(machine.value.id));
    form.append('customerid', String(customerId.value));
    form.append('amount', Number(amount.value).toFixed(2));
    form.append('image', photoFile.value,
      photoFile.value.name || `ticketout-${machine.value.machineNumber}-${Date.now()}.jpg`);

    const response = await saveTicketOut(form);
    ElMessage.success(response.message || 'Ticket Out saved.');
    await loadState();
    await resetToScan();
  } catch (error) {
    ElMessage.error(error?.response?.data?.message || error?.message || 'Unable to save Ticket Out.');
  } finally {
    saving.value = false;
  }
}

onMounted(async () => {
  await loadState();
  await nextTick();
  updateActionBarPosition();

  if (ticketPageRef.value) {
    actionBarResizeObserver = new ResizeObserver(scheduleActionBarUpdate);
    actionBarResizeObserver.observe(ticketPageRef.value);
  }
  window.addEventListener('resize', scheduleActionBarUpdate);
  window.addEventListener('transitionend', scheduleActionBarUpdate);

  await scanNfc();
});

onBeforeUnmount(async () => {
  await stopNfcScan();
  actionBarResizeObserver?.disconnect();
  cancelAnimationFrame(actionBarFrame);
  window.removeEventListener('resize', scheduleActionBarUpdate);
  window.removeEventListener('transitionend', scheduleActionBarUpdate);
  if (photoPreview.value) URL.revokeObjectURL(photoPreview.value);
});
</script>

<style scoped>
  .ticketout-page {
    width: 100%;
    max-width: none;
    margin: 0;
    padding: 20px 20px 85px;
    min-height: calc(100dvh - 50px);
    box-sizing: border-box;
    overflow-x: hidden;
  }

  .ticket-topbar {
    margin-bottom: 16px;
  }

    .ticket-topbar h2 {
      margin: 0;
      font-size: 24px;
    }

    .ticket-topbar p {
      margin: 4px 0 0;
      color: var(--el-text-color-secondary);
      font-size: 13px;
    }

  .cash-alert {
    margin-bottom: 14px;
  }

  .main-card {
    max-width: 720px;
    margin: 0 auto;
    border-radius: 18px;
  }

  .scan-card :deep(.el-card__body) {
    padding: 30px 28px 26px;
  }

  .scan-stage {
    text-align: center;
    padding: 14px 0 18px;
  }

    .scan-stage h3 {
      margin: 20px 0 5px;
      font-size: 22px;
    }

  .scan-status {
    margin: 0;
    color: var(--el-text-color-secondary);
    font-size: 13px;
  }

  .scan-again {
    margin-top: 18px;
    min-width: 190px;
  }

  .nfc-animation {
    position: relative;
    width: 190px;
    height: 150px;
    margin: 0 auto;
  }

  .phone {
    position: absolute;
    left: 32px;
    top: 20px;
    width: 64px;
    height: 108px;
    border: 4px solid var(--el-text-color-primary);
    border-radius: 14px;
    background: var(--el-bg-color);
    display: grid;
    place-items: center;
    z-index: 3;
  }

    .phone::after {
      content: "";
      position: absolute;
      bottom: 6px;
      width: 18px;
      height: 3px;
      border-radius: 4px;
      background: var(--el-text-color-primary);
      opacity: .35;
    }

    .phone .el-icon {
      font-size: 30px;
      color: var(--el-color-primary);
    }

  .wave {
    position: absolute;
    left: 91px;
    top: 75px;
    border: 3px solid var(--el-color-primary);
    border-left: 0;
    border-top-color: transparent;
    border-bottom-color: transparent;
    border-radius: 0 50% 50% 0;
    transform: translateY(-50%);
    opacity: .22;
  }

  .wave-1 {
    width: 24px;
    height: 44px;
  }

  .wave-2 {
    width: 46px;
    height: 76px;
  }

  .wave-3 {
    width: 68px;
    height: 108px;
  }

  .nfc-animation.scanning .wave-1 {
    animation: nfcPulse 1.35s ease-in-out infinite;
  }

  .nfc-animation.scanning .wave-2 {
    animation: nfcPulse 1.35s ease-in-out .18s infinite;
  }

  .nfc-animation.scanning .wave-3 {
    animation: nfcPulse 1.35s ease-in-out .36s infinite;
  }

  .nfc-animation.scanning .phone {
    animation: phoneFloat 1.8s ease-in-out infinite;
  }

  @keyframes nfcPulse {
    0%, 100% {
      opacity: .16;
      transform: translateY(-50%) scale(.94);
    }

    50% {
      opacity: 1;
      transform: translateY(-50%) scale(1.05);
    }
  }

  @keyframes phoneFloat {
    0%, 100% {
      transform: translateY(0);
    }

    50% {
      transform: translateY(-4px);
    }
  }

  .manual-divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 8px 0 16px;
    color: var(--el-text-color-secondary);
    font-size: 10px;
    font-weight: 700;
    letter-spacing: .6px;
  }

    .manual-divider::before, .manual-divider::after {
      content: "";
      height: 1px;
      background: var(--el-border-color-lighter);
      flex: 1;
    }

  .manual-box {
    max-width: 430px;
    margin: 0 auto;
  }

  .input-label {
    display: block;
    margin-bottom: 6px;
    font-size: 11px;
    font-weight: 600;
    color: var(--el-text-color-secondary);
  }

  .machine-input-row {
    display: flex;
    gap: 8px;
  }

  .details-page {
    width: 100%;
  }

  .summary-row {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
    max-width: 600px;
    margin: 0 auto 14px;
  }

  .value-box {
    padding: 13px 16px;
    border: 1px solid var(--el-border-color-lighter);
    border-radius: 12px;
    background: var(--el-fill-color-light);
    text-align: center;
  }

    .value-box small {
      display: block;
      font-size: 10px;
      font-weight: 800;
      color: var(--el-text-color-secondary);
      letter-spacing: 1px;
    }

    .value-box strong {
      display: block;
      margin-top: 4px;
      font-size: 28px;
      font-weight: 900;
      color: #887baf;
    }

  .detail-card {
    height: 100%;
    border-radius: 12px;
  }

    .detail-card :deep(.el-card__header) {
      padding: 14px 16px;
    }

    .detail-card :deep(.el-card__body) {
      padding: 16px;
    }

  .small-text {
    margin-top: 2px;
    color: var(--el-text-color-secondary);
    font-size: 12px;
  }

  .money-input :deep(.el-input__wrapper) {
    min-height: 52px;
  }

  .money-input :deep(.el-input__inner) {
    font-size: 22px;
    font-weight: 800;
  }

  .camera-card {
    overflow: hidden;
  }

    .camera-card :deep(.el-card__body) {
      padding: 0 !important;
      overflow: visible;
    }

  .camera-frame {
    width: 100%;
    min-height: 375px;
    background: #000;
    overflow: visible;
  }

  .photo-preview {
    position: relative;
    width: 100%;
    height: 375px;
    overflow: hidden;
    background: #000;
  }

    .photo-preview img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .photo-preview .el-button {
      position: absolute;
      right: 12px;
      bottom: 12px;
      z-index: 2;
    }

  .fixed-actions {
    position: fixed;
    right: auto;
    bottom: 0;
    z-index: 1000;
    box-sizing: border-box;
    border-top: 1px solid var(--el-border-color-lighter);
    background: rgba(255,255,255,.97);
    box-shadow: 0 -3px 14px rgba(0,0,0,.08);
    backdrop-filter: blur(10px);
    transition: left .28s ease, width .28s ease;
    padding: 0;
  }

  .action-inner {
    width: 100%;
    min-height: 64px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
  }

  .action-left, .action-right {
    display: flex;
    align-items: center;
  }

  .action-right {
    justify-content: flex-end;
    margin-left: auto;
  }

  .action-bar-fade-enter-active {
    transition: opacity .36s ease, transform .36s cubic-bezier(.22,1,.36,1);
  }

  .action-bar-fade-leave-active {
    transition: opacity .30s ease, transform .30s cubic-bezier(.4,0,1,1);
  }

  .action-bar-fade-enter-from, .action-bar-fade-leave-to {
    opacity: 0;
    transform: translateY(110%);
  }

  .step-fade-enter-active, .step-fade-leave-active {
    transition: opacity .2s ease, transform .2s ease;
  }

  .step-fade-enter-from {
    opacity: 0;
    transform: translateY(8px);
  }

  .step-fade-leave-to {
    opacity: 0;
    transform: translateY(-6px);
  }

  @media (max-width: 767px) {
    .ticketout-page {
      padding: 12px 12px 75px;
    }

    .ticket-topbar {
      margin-bottom: 10px;
    }

      .ticket-topbar h2 {
        font-size: 22px;
      }

      .ticket-topbar p {
        font-size: 12px;
      }

    .scan-card :deep(.el-card__body) {
      padding: 20px 16px;
    }

    .scan-stage {
      padding: 6px 0 12px;
    }

      .scan-stage h3 {
        font-size: 19px;
        margin-top: 12px;
      }

    .nfc-animation {
      transform: scale(.88);
      margin-top: -8px;
      margin-bottom: -8px;
    }

    .summary-row {
      gap: 8px;
      margin-bottom: 10px;
    }

    .value-box {
      padding: 11px 8px;
    }

      .value-box strong {
        font-size: 24px;
      }

    .detail-card {
      margin-bottom: 12px;
    }

    .camera-frame {
      min-height: 320px;
    }

    .photo-preview {
      height: 320px;
    }

    .action-inner {
      min-height: 64px;
      padding: 10px 12px;
    }
  }
</style>
