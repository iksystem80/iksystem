<template>
  <div class="sidebar-logo-container"
       :class="{ collapse }">
    <transition name="sidebarLogoFade">
      <router-link :key="collapse ? 'collapse' : 'expand'"
                   class="sidebar-logo-link"
                   to="/">
        <img v-if="logo"
             :src="logo"
             class="sidebar-logo" />

        <h1 v-if="!collapse || !logo"
            class="sidebar-title">
          {{ title }}
        </h1>
      </router-link>
    </transition>
  </div>
</template>

<script setup lang="ts">
    interface Props {
        collapse: boolean
    }

defineProps<Props>();

const title = 'IKlogy - Business Made Simple';

const logo = '@/assets/logo.png';
</script>

<style lang="scss" scoped>
    .sidebarLogoFade-enter-active {
        transition: opacity 1.5s;
    }

    .sidebarLogoFade-enter-from,
    .sidebarLogoFade-leave-to {
        opacity: 0;
    }

    .sidebar-logo-container {
        position: relative;
        width: 100%;
        height: 50px;
        line-height: 50px;
        background: transparent;
        padding: 0 0 0 10px;
        overflow: hidden;

        .sidebar-logo-link {
            display: block;
            height: 100%;
            width: 100%;

            .sidebar-logo {
                width: 32px;
                height: 32px;
                vertical-align: middle;
                margin-right: 12px;
            }

            .sidebar-title {
                display: inline-block;
                margin: 0;
                color: #fff;
                font-weight: 600;
                line-height: 50px;
                font-size: 14px;
                font-family: Avenir, Helvetica Neue, Arial, Helvetica, sans-serif;
                vertical-align: middle;
            }
        }

        &.collapse {
            .sidebar-logo {
                margin-right: 0;
            }
        }
    }
</style>
